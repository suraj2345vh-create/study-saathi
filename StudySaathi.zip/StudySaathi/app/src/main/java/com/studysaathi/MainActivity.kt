package com.studysaathi
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed class Screen {
    object Home : Screen(); object Progress : Screen(); object Search : Screen()
    data class Books(val mode: Int) : Screen()           // 0 read, 1 listen, 2 notes, 3 practice
    data class Reader(val id: String, val mode: Int) : Screen()
}

class MainActivity : ComponentActivity() {
    private lateinit var sp: Speaker
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val repo = Repo(this); val prefs = Prefs(this); sp = Speaker(this)
        setContent { App(repo, prefs, sp) }
    }
    override fun onDestroy() { sp.shutdown(); super.onDestroy() }
}

@Composable
fun BigBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) =
    Button(onClick, modifier.heightIn(min = 56.dp)) { Text(text, fontSize = 18.sp) }

@Composable
fun App(repo: Repo, prefs: Prefs, sp: Speaker) {
    var dark by remember { mutableStateOf(prefs.dark) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    MaterialTheme(if (dark) darkColorScheme() else lightColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            BackHandler(screen != Screen.Home) {
                sp.stop(); val s = screen
                screen = if (s is Screen.Reader) Screen.Books(s.mode) else Screen.Home
            }
            Column(Modifier.statusBarsPadding().padding(16.dp)) {
                when (val s = screen) {
                    Screen.Home -> Home(prefs, repo, dark, { dark = it; prefs.dark = it }) { screen = it }
                    Screen.Progress -> ProgressScreen(repo, prefs)
                    Screen.Search -> SearchScreen(repo) { screen = Screen.Reader(it, 0) }
                    is Screen.Books -> Books(repo, prefs, s.mode) { screen = Screen.Reader(it, s.mode) }
                    is Screen.Reader -> ReaderScreen(repo, prefs, sp, s.id, s.mode)
                }
            }
        }
    }
}

@Composable
fun Home(prefs: Prefs, repo: Repo, dark: Boolean, onDark: (Boolean) -> Unit, go: (Screen) -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📘 10th Study Saathi", fontSize = 24.sp, modifier = Modifier.weight(1f))
            Text("🌙"); Switch(dark, onDark)
        }
        if (prefs.last.isNotEmpty()) BigBtn("▶ जहाँ छोड़ा था: ${repo.find(prefs.last).second.title}", Modifier.fillMaxWidth()) { go(Screen.Reader(prefs.last, 0)) }
        BigBtn("📚 मेरी किताबें", Modifier.fillMaxWidth()) { go(Screen.Books(0)) }
        BigBtn("🔊 सुनकर पढ़ो", Modifier.fillMaxWidth()) { go(Screen.Books(1)) }
        BigBtn("📝 Notes", Modifier.fillMaxWidth()) { go(Screen.Books(2)) }
        BigBtn("❓ Practice", Modifier.fillMaxWidth()) { go(Screen.Books(3)) }
        BigBtn("📊 मेरी Progress", Modifier.fillMaxWidth()) { go(Screen.Progress) }
        BigBtn("🔍 खोजें", Modifier.fillMaxWidth()) { go(Screen.Search) }
    }
}

@Composable
fun Books(repo: Repo, prefs: Prefs, mode: Int, open: (String) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        repo.subjects.forEach { s ->
            item { Text(s.name, fontSize = 22.sp, modifier = Modifier.padding(top = 8.dp)) }
            s.chapters.forEach { c ->
                item { BigBtn((if (prefs.done(c.id)) "✅ " else "") + c.title, Modifier.fillMaxWidth()) { open(c.id) } }
            }
        }
    }
}

@Composable
fun ProgressScreen(repo: Repo, prefs: Prefs) {
    val done = repo.all.count { prefs.done(it.second.id) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("📊 मेरी Progress", fontSize = 24.sp)
        Text("पूरे किए: $done / ${repo.all.size} chapters  (बाकी: ${repo.all.size - done})", fontSize = 18.sp)
        LinearProgressIndicator(progress = { done / repo.all.size.toFloat() }, Modifier.fillMaxWidth().height(10.dp))
        if (prefs.last.isNotEmpty()) Text("पिछला chapter: ${repo.find(prefs.last).second.title}")
        repo.all.forEach { (_, c) -> val sc = prefs.score(c.id)
            Text("• ${c.title}: " + if (sc < 0) "quiz बाकी" else "$sc%", fontSize = 16.sp) }
    }
}

@Composable
fun SearchScreen(repo: Repo, open: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("खोजें (जैसे: प्रकाश संश्लेषण)") })
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            repo.search(q).forEach { (s, c, snip) ->
                item { Card(Modifier.fillMaxWidth().clickable { open(c.id) }) {
                    Column(Modifier.padding(12.dp)) { Text("${s.name} › ${c.title}", fontSize = 18.sp); Text(snip, maxLines = 2) } } }
            }
        }
    }
}

@Composable
fun ReaderScreen(repo: Repo, prefs: Prefs, sp: Speaker, id: String, mode: Int) {
    val (subj, ch) = remember(id) { repo.find(id) }
    var tab by remember { mutableIntStateOf(if (mode == 2) 1 else if (mode == 3) 2 else 0) }
    var cur by remember { mutableIntStateOf(prefs.bookmark(id).coerceAtLeast(0)) }
    var playing by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(prefs.speed) }
    var bm by remember { mutableIntStateOf(prefs.bookmark(id)) }
    LaunchedEffect(id) { prefs.last = id }
    DisposableEffect(id) { sp.onPara = { cur = it }; sp.onDone = { playing = false }; onDispose { sp.stop() } }
    Column {
        Text(ch.title, fontSize = 24.sp)
        Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("पढ़ें", "Notes", "Quiz", "प्रश्न-उत्तर").forEachIndexed { i, t ->
                if (tab == i) Button({}) { Text(t) } else OutlinedButton({ sp.stop(); playing = false; tab = i }) { Text(t) } }
        }
        when (tab) {
            0 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    BigBtn(if (playing) "⏸" else "🔊 सुनें") {
                        if (playing) { sp.stop(); playing = false } else { sp.play(ch.paras, cur, subj.lang, speed); playing = true } }
                    OutlinedButton({ sp.stop(); playing = false }) { Text("⏹") }
                    OutlinedButton({ cur = (cur - 1).coerceAtLeast(0); if (playing) sp.play(ch.paras, cur, subj.lang, speed) }) { Text("⏪") }
                    OutlinedButton({ cur = (cur + 1).coerceAtMost(ch.paras.lastIndex); if (playing) sp.play(ch.paras, cur, subj.lang, speed) }) { Text("⏩") }
                    OutlinedButton({ val l = listOf(0.75f, 1f, 1.25f, 1.5f); speed = l[(l.indexOf(speed) + 1) % l.size]; prefs.speed = speed }) { Text("${speed}x") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton({ bm = cur; prefs.setBookmark(id, cur) }) { Text(if (bm >= 0) "🔖 सेव (${bm + 1})" else "🔖 Bookmark") }
                    OutlinedButton({ prefs.setDone(id) }) { Text(if (prefs.done(id)) "✅ पूरा" else "☑ पूरा करें") }
                }
                LazyColumn(Modifier.weight(1f)) {
                    itemsIndexed(ch.paras) { i, p ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { cur = i; sp.play(ch.paras, i, subj.lang, speed, single = true); playing = false },
                            colors = CardDefaults.cardColors(containerColor = if (i == cur) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                            Text(p, Modifier.padding(12.dp), fontSize = 20.sp, lineHeight = 30.sp) } }
                }
                val ids = repo.subjects.first { it.id == subj.id }.chapters.map { it.id }
                val k = ids.indexOf(id)
                Text("(किसी paragraph पर tap करें = सिर्फ़ वही सुनें)", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (k > 0) OutlinedButton({ nav(repo, prefs, ids[k - 1]) }) { Text("← पिछला") }
                    if (k < ids.lastIndex) OutlinedButton({ nav(repo, prefs, ids[k + 1]) }) { Text("अगला →") }
                }
            }
            1 -> Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ch.notes.forEach { Text("• $it", fontSize = 20.sp, lineHeight = 30.sp) } }
            2 -> Quiz(ch, prefs)
            else -> QAList(ch)
        }
    }
}

private fun nav(repo: Repo, prefs: Prefs, id: String) { prefs.last = id }

@Composable
fun Quiz(ch: Chapter, prefs: Prefs) {
    var qs by remember { mutableStateOf(ch.mcq) }
    var i by remember { mutableIntStateOf(0) }
    var pick by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    var wrong by remember { mutableStateOf(listOf<Q>()) }
    if (i >= qs.size) {
        val pct = score * 100 / qs.size
        LaunchedEffect(Unit) { if (qs.size == ch.mcq.size) prefs.setScore(ch.id, pct) }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Score: $score / ${qs.size} ($pct%)", fontSize = 24.sp)
            if (wrong.isNotEmpty()) BigBtn("❌ गलत प्रश्न दोबारा (${wrong.size})") { qs = wrong; wrong = listOf(); i = 0; score = 0; pick = -1 }
            BigBtn("🔁 फिर से Quiz") { qs = ch.mcq; wrong = listOf(); i = 0; score = 0; pick = -1 }
        }
        return
    }
    val q = qs[i]
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("प्रश्न ${i + 1}/${qs.size}"); Text(q.q, fontSize = 20.sp)
        q.o.forEachIndexed { k, o ->
            val tag = if (pick < 0) "" else if (k == q.a) " ✅" else if (k == pick) " ❌" else ""
            OutlinedButton({ if (pick < 0) { pick = k; if (k == q.a) score++ else wrong = wrong + q } }, Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text(o + tag, fontSize = 18.sp) } }
        if (pick >= 0) BigBtn("आगे →") { i++; pick = -1 }
    }
}

@Composable
fun QAList(ch: Chapter) {
    if (ch.qa.isEmpty()) { Text("इस chapter के प्रश्न-उत्तर जल्द जोड़े जाएँगे।"); return }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(ch.qa) { i, x ->
            var show by remember(ch.id, i) { mutableStateOf(false) }
            Card(Modifier.fillMaxWidth().clickable { show = !show }) {
                Column(Modifier.padding(12.dp)) {
                    Text("प्र${i + 1}. ${x.q}", fontSize = 20.sp)
                    Text(if (show) "उ. ${x.a}" else "👆 उत्तर देखने के लिए tap करें", fontSize = 18.sp, lineHeight = 28.sp,
                        modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}
