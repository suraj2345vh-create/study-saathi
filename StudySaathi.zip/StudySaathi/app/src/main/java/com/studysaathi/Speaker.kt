package com.studysaathi
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

/** Wraps Android TextToSpeech (uses the phone's offline voices if installed). */
class Speaker(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var tts: TextToSpeech? = TextToSpeech(ctx) { ready = it == TextToSpeech.SUCCESS }
    var onPara: (Int) -> Unit = {}
    var onDone: () -> Unit = {}

    fun play(paras: List<String>, from: Int, lang: String, rate: Float, single: Boolean = false) {
        val t = tts ?: return
        if (!ready) { Toast.makeText(ctx, "TTS तैयार नहीं है", Toast.LENGTH_SHORT).show(); return }
        val r = t.setLanguage(if (lang == "hi") Locale("hi", "IN") else Locale.ENGLISH)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(ctx, "फोन की Settings में इस भाषा की आवाज़ (voice) इंस्टॉल करें", Toast.LENGTH_LONG).show(); return
        }
        t.stop(); t.setSpeechRate(rate)
        val end = if (single) from + 1 else paras.size
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String) { main.post { onPara(id.toInt()) } }
            override fun onDone(id: String) { if (id.toInt() == end - 1) main.post { onDone() } }
            @Deprecated("") override fun onError(id: String) {}
        })
        for (i in from until end) t.speak(paras[i], TextToSpeech.QUEUE_ADD, null, i.toString())
    }
    fun stop() { tts?.stop() }
    fun shutdown() { tts?.shutdown(); tts = null }
}
