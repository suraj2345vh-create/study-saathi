package com.studysaathi
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Q(val q: String, val o: List<String>, val a: Int)
data class QA(val q: String, val a: String)
data class Chapter(val id: String, val title: String, val paras: List<String>, val notes: List<String>, val mcq: List<Q>, val qa: List<QA> = emptyList())
data class Subject(val id: String, val name: String, val lang: String, val chapters: List<Chapter>)

private fun JSONArray.strs() = List(length()) { getString(it) }

/** Loads content.json. A downloaded update at filesDir/content.json overrides the bundled copy (offline-safe). */
class Repo(ctx: Context) {
    val subjects: List<Subject>
    init {
        val f = File(ctx.filesDir, "content.json")
        val txt = if (f.exists()) f.readText() else ctx.assets.open("content.json").bufferedReader().readText()
        subjects = parse(JSONObject(txt).getJSONArray("subjects"))
    }
    private fun parse(a: JSONArray) = List(a.length()) { i ->
        val s = a.getJSONObject(i)
        val cs = s.getJSONArray("chapters")
        Subject(s.getString("id"), s.getString("name"), s.getString("lang"), List(cs.length()) { j ->
            val c = cs.getJSONObject(j); val m = c.getJSONArray("mcq")
            Chapter(c.getString("id"), c.getString("title"), c.getJSONArray("paras").strs(), c.getJSONArray("notes").strs(),
                List(m.length()) { k -> val q = m.getJSONObject(k); Q(q.getString("q"), q.getJSONArray("o").strs(), q.getInt("a")) },
                c.optJSONArray("qa")?.let { x -> List(x.length()) { k -> QA(x.getJSONObject(k).getString("q"), x.getJSONObject(k).getString("a")) } } ?: emptyList())
        })
    }
    val all = subjects.flatMap { s -> s.chapters.map { s to it } }
    fun find(id: String) = all.first { it.second.id == id }
    fun search(q: String) = if (q.length < 2) emptyList() else all.mapNotNull { (s, c) ->
        val hit = (c.paras + c.notes + c.qa.map { it.q + " " + it.a }).firstOrNull { it.contains(q, true) }
        if (hit != null || c.title.contains(q, true)) Triple(s, c, hit ?: c.title) else null
    }
}

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("saathi", Context.MODE_PRIVATE)
    var dark: Boolean get() = p.getBoolean("dark", false); set(v) = p.edit().putBoolean("dark", v).apply()
    var speed: Float get() = p.getFloat("speed", 1f); set(v) = p.edit().putFloat("speed", v).apply()
    var last: String get() = p.getString("last", "") ?: ""; set(v) = p.edit().putString("last", v).apply()
    fun done(id: String) = p.getBoolean("d_$id", false)
    fun setDone(id: String) = p.edit().putBoolean("d_$id", true).apply()
    fun score(id: String) = p.getInt("s_$id", -1)
    fun setScore(id: String, v: Int) = p.edit().putInt("s_$id", v).apply()
    fun userText(id: String): String? = p.getString("t_$id", null)
    fun setUserText(id: String, v: String?) { val e = p.edit(); if (v.isNullOrBlank()) e.remove("t_$id") else e.putString("t_$id", v); e.apply() }
    /** All progress, bookmarks and pasted lesson text as one JSON string (for backup). */
    fun exportJson(): String { val o = JSONObject(); for ((k, v) in p.all) if (v is Boolean || v is Int || v is Float || v is String) o.put(k, v); return o.toString() }
    fun importJson(s: String) { val o = JSONObject(s); val e = p.edit()
        for (k in o.keys()) when (val v = o.get(k)) { is Boolean -> e.putBoolean(k, v); is Int -> e.putInt(k, v); is Double -> e.putFloat(k, v.toFloat()); is String -> e.putString(k, v) }
        e.apply() }
    fun bookmark(id: String) = p.getInt("b_$id", -1)
    fun setBookmark(id: String, v: Int) = p.edit().putInt("b_$id", v).apply()
}
