plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.studysaathi"
    compileSdk = 34
    defaultConfig { applicationId = "com.studysaathi"; minSdk = 21; targetSdk = 34; versionCode = 1; versionName = "0.1" }
    // Fixed key: every new APK is signed the same way, so it installs over the old app and keeps its data.
    signingConfigs { getByName("debug") {
        storeFile = file("studysaathi.keystore"); storePassword = "studysaathi"
        keyAlias = "studysaathi"; keyPassword = "studysaathi" } }
    buildTypes { release { isMinifyEnabled = true; isShrinkResources = true
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.0")
}
